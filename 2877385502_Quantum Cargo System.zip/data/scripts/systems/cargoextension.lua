package.path = package.path .. ";data/scripts/systems/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"
include ("basesystem")
include ("utility")
include ("randomext")

-- optimization so that energy requirement doesn't have to be read every frame
FixedEnergyRequirement = true

function getBonuses(seed, rarity, permanent)
    math.randomseed(seed)

    local perc = 25 -- base value, in percent
    -- add flat percentage based on rarity
    perc = perc + rarity.value * 8 -- add -4% (worst rarity) to +20% (best rarity) - MOD: increased base amount of relative cargo

    -- add randomized percentage, span is based on rarity
    perc = perc + math.random() * 8 -- add random value between 0% - 4% - MOD: doubled the added value
    -- perc = perc * 0.8
    perc = perc / 100
    if permanent then perc = perc * 1.5 end

    local flat = 50 -- base value - MOD: increased base flat amount
    -- add flat value based on rarity
    flat = flat + (rarity.value + 3) * 50 -- add +0 (worst rarity) to +300 (best rarity) - MOD: increased flat amount that is added from rarity

    -- add randomized value, span is based on rarity
    flat = flat + math.random() * ((rarity.value + 1) * 50) -- add random value between +0 (worst rarity) and +300 (best rarity)
    flat = flat * 0.8
    if permanent then flat = flat * 1.5 end
    flat = round(flat)

    -- if math.random() < 0.5 then
    --     perc = 0
    -- else
    --     flat = 0
    -- end

    return perc, flat
end

function getTooltipLines(seed, rarity, permanent)

    local texts = {}
    local bonuses = {}
    local perc, flat = getBonuses(seed, rarity, permanent)
    local basePerc, baseFlat = getBonuses(seed, rarity, false)

    -- if perc ~= 0 then
        table.insert(texts, {ltext = "Cargo Hold (relative)"%_t, rtext = string.format("%+i%%", round(perc * 100)), icon = "data/textures/icons/crate.png", boosted = permanent})
        table.insert(bonuses, {ltext = "Cargo Hold (relative)"%_t, rtext = string.format("%+i%%", round(basePerc * 0.5 * 100)), icon = "data/textures/icons/crate.png", boosted = permanent})
    -- end

    -- if flat ~= 0 then
        table.insert(texts, {ltext = "Cargo Hold"%_t, rtext = string.format("%+i", round(flat)), icon = "data/textures/icons/crate.png", boosted = permanent})
        table.insert(bonuses, {ltext = "Cargo Hold"%_t, rtext = string.format("%+i", round(baseFlat * 0.5)), icon = "data/textures/icons/crate.png", boosted = permanent})
    -- end

    return texts, bonuses
end

function getComparableValues(seed, rarity)
    local perc, flat = getBonuses(seed, rarity, false)

    local base = {}
    local bonus = {}
    -- if perc ~= 0 then
        table.insert(base, {name = "Cargo Hold (relative)"%_t, key = "cargo_hold_relative", value = round(perc * 100), comp = UpgradeComparison.MoreIsBetter})
        table.insert(bonus, {name = "Cargo Hold (relative)"%_t, key = "cargo_hold_relative", value = round(perc * 0.5 * 100), comp = UpgradeComparison.MoreIsBetter})
    -- end

    -- if flat ~= 0 then
        table.insert(base, {name = "Cargo Hold"%_t, key = "cargo_hold", value = round(flat), comp = UpgradeComparison.MoreIsBetter})
        table.insert(bonus, {name = "Cargo Hold"%_t, key = "cargo_hold", value = round(flat * 0.5), comp = UpgradeComparison.MoreIsBetter})
    -- end

    return base, bonus
end
